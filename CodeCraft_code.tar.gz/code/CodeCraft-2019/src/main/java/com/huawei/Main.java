package com.huawei;

import org.apache.log4j.Logger;
import java.util.*;

public class Main {
    private static final Logger logger = Logger.getLogger(Main.class);
    public static void main(String[] args) throws Exception {
        long startTime = System.currentTimeMillis();
        if (args.length != 4) {
            logger.error("please input args: inputFilePath, resultFilePath");
            return;
        }

        logger.info("Start...");

        String carPath = args[0];
        String roadPath = args[1];
        String crossPath = args[2];
        String answerPath = args[3];
        logger.info("carPath = " + carPath + " roadPath = " + roadPath + " crossPath = " + crossPath + " and answerPath = " + answerPath);

        // TODO:read input files
        logger.info("start read input files");
        ArrayList<Car> carList = IO.loadCarData(carPath);
        ArrayList<Road> roadList = IO.loadRoadData(roadPath);
        ArrayList<Cross> crossList = IO.loadCrossData(crossPath);
        Vars vars = new Vars(carList, roadList, crossList);
        // 规划路径列表
        ArrayList<Route> routeList = new ArrayList<>();
        for (int i = 0; i < carList.size(); i++) {
            Car car = carList.get(i);
            routeList.add(new Route(car.id, 0, null));
        }

        // TODO: group
        ArrayList<Car> one = new ArrayList<>();
        ArrayList<Car> two = new ArrayList<>();
        Statistics stat = new Statistics(vars);
        double ratio = stat.group(one, two);

        // TODO: calc
        int K = 10;
        Dijkstra dijkstra = new Dijkstra(vars, K);

        // TODO: test dispatcher
        Dispatcher dispatcher = new Dispatcher(vars);
        int base = vars.carList.size();  // 问题规模参考值
        int res = -1;
        int ddt = 140;
        int interval = ddt;     // 两组车的发车间隔
        int tryTime = 1;
        int nps = 30;
        Random random = new Random(47);
        do {
            logger.info("--------------- Try Time: " + tryTime + "----------------");
            int cutoff = (int)(ddt * ratio);
            /**** 每组按速度排序 ****/
            int[][] groupOne = RandomTime.randomTimeBySpeed(random, cutoff, one);
            int[][] groupTwo = RandomTime.randomTimeBySpeed(random, ddt - cutoff, two);
            /****  ****/
            int dt = 1;
            for (int i = 0; i < routeList.size(); i++) {
                Car car;
//                int dt;
//                if (i < one.size()) {   // group one
//////                    dt = random.nextInt(cutoff);
//////                    car = one.get(i);
//////                    dt = 0;
////                    dt = groupOne[i][0];
////                    car = vars.carMap.get(groupOne[i][1]);
////                } else {
//////                    dt = random.nextInt(ddt - cutoff) + cutoff + 200;
//////                    car = two.get(i-one.size());
//////                    dt = 350;
////                    dt = groupTwo[i-one.size()][0] + cutoff + interval;
////                    car = vars.carMap.get(groupTwo[i-one.size()][1]);
////                }
                car = vars.carList.get(i);

                int randRouteId = (int)(Math.random()*K);
                int fromIdx = vars.crossIdxMap.get(car.from);
                int toIdx = vars.crossIdxMap.get(car.to);
                routeList.get(i).reset();
                routeList.get(i).carId = car.id;
                routeList.get(i).startTime = car.planTime + dt;
                routeList.get(i).roadIds = dijkstra.pathLists[fromIdx][toIdx].getPath(randRouteId);
//                routeList.get(i).roadIds = dijkstra.pathLists[fromIdx][toIdx].getPath(0);
                if (i % nps == 0) {
                    dt+= 1;
                }
            }
            vars.setRoutes(routeList);
            res = dispatcher.dispatch();
            vars.reset();
            ddt += 1;
            interval = ddt;
            tryTime++;
            if (nps > 23) {
                nps--;
            }
        } while (res == -1);
        logger.info("ddt: " + ddt);
        logger.info("interval: " + interval);

        // TODO: write answer.txt
        logger.info("Start write output file");
        IO.writeAnswer(answerPath, routeList);
        long endTime = System.currentTimeMillis();
        logger.info("程序运行时间：" + (endTime - startTime) + "ms");    // 程序运行时间

//        long totalTime = 0;
//        for (Car car: carList) {
//            totalTime += (car.reachTime - car.planTime);
//        }
//        logger.info("车辆总调度时间：" + totalTime);

        logger.info("End...");
    }
}