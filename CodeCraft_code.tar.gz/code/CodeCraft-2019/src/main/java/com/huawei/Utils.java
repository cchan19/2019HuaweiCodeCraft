package com.huawei;

public class Utils {

}
